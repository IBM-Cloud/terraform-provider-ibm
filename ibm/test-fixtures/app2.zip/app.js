var http = require('http');

var host = process.env.VCAP_APP_HOST || 'localhost';
var port = process.env.VCAP_APP_PORT || 1337

var vcap_services
if (process.env.VCAP_SERVICES){
     env = JSON.parse(process.env.VCAP_SERVICES);
     vcap_services  = JSON.stringify(env, null, 4);
}
var user
if(process.env.test){
 myEnv = process.env.test;
 user  = JSON.stringify(myEnv, null, 4);
}

http.createServer(function(req, res) {
    res.writeHead(200, {
        'Content-Type': 'text/html'
    });
    res.end('Hello Terraform  Tester! Application version 2 is running ' + vcap_services +user);

}).listen(port, null);

console.log('Server running at http://' + host + ':' + port + '/');
